



package me.earth.phobos.features.gui.custom;

import net.minecraft.client.gui.*;
import net.minecraft.client.*;

public class GuiCustomNewChat extends GuiNewChat
{
    public GuiCustomNewChat(final Minecraft mcIn) {
        super(mcIn);
    }
}
