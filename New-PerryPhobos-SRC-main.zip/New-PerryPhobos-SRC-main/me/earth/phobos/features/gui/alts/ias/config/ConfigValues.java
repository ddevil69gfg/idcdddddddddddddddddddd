



package me.earth.phobos.features.gui.alts.ias.config;

public class ConfigValues
{
    public static final boolean CASESENSITIVE_DEFAULT = false;
    public static final String CASESENSITIVE_NAME = "ias.cfg.casesensitive";
    public static final boolean ENABLERELOG_DEFAULT = false;
    public static final String ENABLERELOG_NAME = "ias.cfg.enablerelog";
    public static boolean CASESENSITIVE;
    public static boolean ENABLERELOG;
}
