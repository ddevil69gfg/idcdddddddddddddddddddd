



package me.earth.phobos.features.gui.alts.ias.enums;

public enum EnumBool
{
    TRUE, 
    FALSE, 
    UNKNOWN;
}
