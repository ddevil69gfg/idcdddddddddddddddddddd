



package me.earth.phobos.features.gui.alts.ias.legacysupport;

public interface ILegacyCompat
{
    int[] getDate();
    
    String getFormattedDate();
}
