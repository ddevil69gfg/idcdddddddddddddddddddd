



package me.earth.phobos.features.modules.player;

import me.earth.phobos.features.modules.*;

public class TrueDurability extends Module
{
    private static TrueDurability instance;
    
    public TrueDurability() {
        super("TrueDurability", "Shows True Durability of items.", Module.Category.PLAYER, false, false, false);
        TrueDurability.instance = this;
    }
    
    public static TrueDurability getInstance() {
        if (TrueDurability.instance == null) {
            TrueDurability.instance = new TrueDurability();
        }
        return TrueDurability.instance;
    }
}
