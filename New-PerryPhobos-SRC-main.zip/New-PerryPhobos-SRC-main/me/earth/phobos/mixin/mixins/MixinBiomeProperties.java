



package me.earth.phobos.mixin.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.world.biome.*;

@Mixin({ Biome.BiomeProperties.class })
public class MixinBiomeProperties
{
}
