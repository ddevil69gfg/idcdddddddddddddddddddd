



package me.earth.phobos.mixin.mixins;

import org.spongepowered.asm.mixin.*;
import net.minecraft.client.model.*;

@Mixin({ ModelPlayer.class })
public class MixinModelPlayer
{
}
