



package org.spongepowered.asm.lib.tree.analysis;

public interface Value
{
    int getSize();
}
